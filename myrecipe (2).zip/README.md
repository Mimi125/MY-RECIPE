# VidJot Project - Node.Js

Ideas for youtube list app

## Usage
If you are in local mode use:

```
npm run dev
```

## Instalation

Install all dependencies

```
npm install
```

## Built With

* Node.Js
* Express.Js
* MongoDB
* Bootstrap

## Author

**germancutraro**

## Thanks to

* [Brad Traversy](https://www.udemy.com/nodejs-express-mongodb-dev-to-deployment/)

## Why

* Practise
